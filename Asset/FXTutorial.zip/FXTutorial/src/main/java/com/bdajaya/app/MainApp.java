package com.bdajaya.app;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class MainApp extends Application {

  public static void main(String[] args) {
    launch(args);
  }

  @Override
  public void start(Stage primaryStage) {
    try {
      // Path absolut ke file FXML
      File fxmlFile = new File("src/main/java/com/bdajaya/view/mainapp.fxml");
      URL fxmlUrl = fxmlFile.toURI().toURL();

      // Muat FXML
      FXMLLoader fxmlLoader = new FXMLLoader(fxmlUrl);
      Parent root = fxmlLoader.load();

      // Tampilkan scene
      Scene scene = new Scene(root);
      primaryStage.setScene(scene);
      primaryStage.setTitle("BDAJAYA");
      primaryStage.show();

    }catch (IOException e) {
      e.printStackTrace();
    }
  }
}
