package com.bdajaya.app;

import com.bdajaya.multiviews.View;
import com.bdajaya.multiviews.ViewSwitcher;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class MultiViewApp extends Application {
  @Override
  public void start(Stage stage) throws Exception {
    var scene = new Scene(new Pane());

    ViewSwitcher.setScene(scene);
    ViewSwitcher.switchTo(View.MAINAPP); // Start with login view

    stage.setScene(scene);
    stage.setTitle("Multi-View Application");
    stage.show();
  }

  public static void main(String[] args) {
    launch(args);
  }
}
