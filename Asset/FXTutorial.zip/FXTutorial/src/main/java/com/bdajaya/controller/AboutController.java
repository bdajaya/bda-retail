package com.bdajaya.controller;

import com.bdajaya.multiviews.View;
import com.bdajaya.multiviews.ViewSwitcher;

public class AboutController {
  public void onBack() {
    ViewSwitcher.switchTo(View.MAIN);
  }

}
