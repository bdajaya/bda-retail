package com.bdajaya.controller;

import com.bdajaya.multiviews.View;
import com.bdajaya.multiviews.ViewSwitcher;

public class LoginController {
  public void onLogin() {
    ViewSwitcher.switchTo(View.LOGIN);
  }

}
