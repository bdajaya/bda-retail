package com.bdajaya.controller;

import com.bdajaya.multiviews.View;
import com.bdajaya.multiviews.ViewSwitcher;

public class MainController {
  public void onAbout() {
    ViewSwitcher.switchTo(View.ABOUT);
  }

}
