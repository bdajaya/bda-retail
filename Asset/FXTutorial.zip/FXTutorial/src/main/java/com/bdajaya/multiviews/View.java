package com.bdajaya.multiviews;

public enum View {
  LOGIN("/multiviews/login.fxml"),
  MAIN("/multiviews/main.fxml"),
  MAINAPP("src/main/java/com/bdajaya/view/mainapp.fxml"),
  ABOUT("/multiviews/about.fxml");

  private String fileName;

  View(String fileName) {
    this.fileName = fileName;
  }

  public String getFileName() {
    return fileName;
  }
}
