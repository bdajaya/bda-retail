package com.bdajaya.multiviews;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class ViewSwitcher {

  private static final Map<View, Parent> cache = new HashMap<>();
  private static Scene scene;

  // Set the scene, this should be called once when initializing the app
  public static void setScene(Scene scene) {
    ViewSwitcher.scene = scene;
  }

  // Switch to the given view
  public static void switchTo(View view) {
    if (scene == null) {
      System.out.println("No scene was set");
      return;
    }

    try {
      Parent root;
      if (cache.containsKey(view)) {
        System.out.println("Loading from cache");
        root = cache.get(view);
      } else {
        System.out.println("Loading from FXML");
        System.out.println("Loading FXML file: " + view.getFileName());
        root = loadFXML(view);  // Will throw IOException if resource not found
        cache.put(view, root);
      }

      scene.setRoot(root);
    } catch (IOException e) {
      System.err.println("Error loading FXML: " + e.getMessage());
      e.printStackTrace();
    }
  }

  // Load FXML file for the given view
  private static Parent loadFXML(View view) throws IOException {
    var resource = ViewSwitcher.class.getResource(view.getFileName());

    if (resource == null) {
      throw new IOException("FXML file not found: " + view.getFileName());
    }

    System.out.println("Loading FXML file: " + view.getFileName());
    FXMLLoader loader = new FXMLLoader(resource);
    return loader.load();
  }
}
