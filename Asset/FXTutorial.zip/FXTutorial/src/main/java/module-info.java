module FXTutorial {
  // Menggunakan JavaFX modules
  requires javafx.controls;
  requires javafx.graphics;
  requires javafx.fxml;

  exports com.bdajaya.app;
  exports com.bdajaya.multiviews;

  opens com.bdajaya.controller to javafx.fxml;

}